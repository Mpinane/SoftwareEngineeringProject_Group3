# users/models.py
from django.contrib.auth.models import AbstractUser, User
from django.db import models


levels = [
    ('select current year', 'SELECT CURRENT YEAR'),
    ('yos1', 'YOS1'),
    ('yos2', 'YOS2'),
    ('yos3', 'YOS3'),
    ('honours', 'HONOURS'),
]


class CustomUser(AbstractUser):
    student_name = models.CharField(max_length=10, blank=False, null=False, default='')
    student_surname = models.CharField(max_length=10, blank=False, null=False, default='')
    student_id = models.CharField(max_length=8, blank=False, null=False, default='')
    # student_id = models.CharField(primary_key=True, max_length=8, null=False, blank=False, default=-1')
    # student_id = models.PositiveIntegerField(primary_key=True, max_length=8, blank=False, null=False, default=-1)
    student_current_level = models.CharField(choices=levels, max_length=10, blank=False, null=False, default=' ')

    def __str__(self):
        return self.email
