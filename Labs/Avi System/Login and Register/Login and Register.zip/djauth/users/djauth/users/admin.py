# users/admin.py
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin
from .forms import CustomUserCreationForm, CustomUserChangeForm
from .models import *


class CustomUserAdmin(UserAdmin):
    add_form = CustomUserCreationForm
    form = CustomUserChangeForm
    model = CustomUser
    list_display = ['username', 'student_id', 'student_name', 'student_surname', 'student_current_level', 'email']    # Edit Accordingly


admin.site.register(CustomUser, CustomUserAdmin)


# admin.site.register(Student)
# admin.site.register(Course)
# admin.site.register(Enrolment)
# admin.site.register(Predicted)
#
